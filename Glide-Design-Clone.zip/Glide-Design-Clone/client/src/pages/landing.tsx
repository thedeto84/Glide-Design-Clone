import { useEffect, useMemo, useState } from "react";
import { motion } from "framer-motion";
import {
  ArrowRight,
  Check,
  ChevronDown,
  Code2,
  Layers,
  LayoutGrid,
  Play,
  Shield,
  Sparkles,
  Wand2,
  Sun,
  Moon,
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Card } from "@/components/ui/card";
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from "@/components/ui/accordion";

type NavItem = { label: string; href: string };

type MiniRow = {
  title: string;
  icon: React.ComponentType<{ className?: string }>;
};

const navLeft: NavItem[] = [
  { label: "Product", href: "#product" },
  { label: "Templates", href: "#templates" },
  { label: "Customers", href: "#customers" },
  { label: "Pricing", href: "#pricing" },
];

const navRight: NavItem[] = [
  { label: "Docs", href: "#docs" },
  { label: "Log in", href: "#login" },
];

function cx(...classes: Array<string | false | undefined | null>) {
  return classes.filter(Boolean).join(" ");
}

function useSmoothHashScroll() {
  useEffect(() => {
    const onClick = (e: MouseEvent) => {
      const target = e.target as HTMLElement | null;
      const a = target?.closest("a[href^='#']") as HTMLAnchorElement | null;
      if (!a) return;
      const hash = a.getAttribute("href");
      if (!hash || hash === "#") return;
      const el = document.querySelector(hash);
      if (!el) return;
      e.preventDefault();
      (el as HTMLElement).scrollIntoView({ behavior: "smooth", block: "start" });
      history.replaceState(null, "", hash);
    };

    window.addEventListener("click", onClick);
    return () => window.removeEventListener("click", onClick);
  }, []);
}

function Container(props: { className?: string; children: React.ReactNode }) {
  return (
    <div className={cx("mx-auto w-full max-w-[1200px] px-4 sm:px-6", props.className)}>
      {props.children}
    </div>
  );
}

function ThemeToggle() {
  const [theme, setTheme] = useState<"light" | "dark">(() => {
    if (typeof window !== "undefined") {
      return document.documentElement.classList.contains("dark") ? "dark" : "light";
    }
    return "light";
  });

  useEffect(() => {
    const root = document.documentElement;
    if (theme === "dark") {
      root.classList.add("dark");
      root.classList.remove("light");
    } else {
      root.classList.add("light");
      root.classList.remove("dark");
    }
  }, [theme]);

  return (
    <Button
      variant="ghost"
      size="icon"
      className="rounded-full"
      onClick={() => setTheme(theme === "light" ? "dark" : "light")}
      data-testid="button-theme-toggle"
      aria-label="Toggle theme"
    >
      {theme === "light" ? <Moon className="h-5 w-5" /> : <Sun className="h-5 w-5" />}
    </Button>
  );
}

function TopNav() {
  const [open, setOpen] = useState(false);

  return (
    <div className="sticky top-0 z-50 border-b bg-background/70 backdrop-blur">
      <Container>
        <div className="flex h-16 items-center justify-between gap-3">
          <a
            href="#"
            className="group flex items-center gap-2"
            data-testid="link-home"
            aria-label="Home"
          >
            <div
              className="grid h-9 w-9 place-items-center rounded-xl bg-gradient-to-br from-[hsl(var(--primary))] to-[hsl(var(--accent))] text-white shadow"
              data-testid="img-brand-mark"
            >
              <Sparkles className="h-5 w-5" aria-hidden={true} />
            </div>
            <div className="leading-none">
              <div className="text-display text-[15px] font-semibold">Glide-ish</div>
              <div className="text-xs text-muted-foreground">Prototype</div>
            </div>
          </a>

          <div className="hidden items-center gap-6 md:flex">
            <nav className="flex items-center gap-5" aria-label="Primary">
              {navLeft.map((item) => (
                <a
                  key={item.label}
                  href={item.href}
                  className="text-sm text-muted-foreground transition-colors hover:text-foreground"
                  data-testid={`link-nav-${item.label.toLowerCase()}`}
                >
                  {item.label}
                </a>
              ))}
            </nav>

            <div className="flex items-center gap-2">
              <ThemeToggle />
              {navRight.map((item) => (
                <a
                  key={item.label}
                  href={item.href}
                  className="text-sm text-muted-foreground transition-colors hover:text-foreground"
                  data-testid={`link-nav-${item.label.toLowerCase().replace(/\s+/g, "-")}`}
                >
                  {item.label}
                </a>
              ))}
              <Button
                className="rounded-full"
                data-testid="button-nav-get-started"
                onClick={() => {
                  const el = document.querySelector("#pricing");
                  (el as HTMLElement | null)?.scrollIntoView({ behavior: "smooth", block: "start" });
                }}
              >
                Get started
                <ArrowRight className="ml-2 h-4 w-4" aria-hidden={true} />
              </Button>
            </div>
          </div>

          <div className="flex items-center gap-2 md:hidden">
            <ThemeToggle />
            <button
              className="focus-ring flex h-10 w-10 items-center justify-center rounded-xl border bg-background"
              onClick={() => setOpen((v) => !v)}
              data-testid="button-mobile-menu"
              aria-label="Open menu"
            >
              <div className="grid gap-1">
                <span className={cx("h-0.5 w-5 rounded bg-foreground transition", open && "translate-y-1.5 rotate-45")} />
                <span className={cx("h-0.5 w-5 rounded bg-foreground transition", open && "opacity-0")} />
                <span className={cx("h-0.5 w-5 rounded bg-foreground transition", open && "-translate-y-1.5 -rotate-45")} />
              </div>
            </button>
          </div>
        </div>

        {open ? (
          <div className="pb-4 md:hidden" data-testid="panel-mobile-menu">
            <div className="grid gap-2 rounded-2xl border bg-background p-3">
              {[...navLeft, ...navRight].map((item) => (
                <a
                  key={item.label}
                  href={item.href}
                  className="rounded-xl px-3 py-2 text-sm text-muted-foreground hover:bg-secondary hover:text-foreground"
                  data-testid={`link-mobile-${item.label.toLowerCase().replace(/\s+/g, "-")}`}
                  onClick={() => setOpen(false)}
                >
                  {item.label}
                </a>
              ))}
              <Button
                className="mt-2 w-full rounded-xl"
                data-testid="button-mobile-get-started"
                onClick={() => {
                  setOpen(false);
                  const el = document.querySelector("#pricing");
                  (el as HTMLElement | null)?.scrollIntoView({ behavior: "smooth", block: "start" });
                }}
              >
                Get started
              </Button>
            </div>
          </div>
        ) : null}
      </Container>
    </div>
  );
}

function Hero() {
  const variants = useMemo(
    () => ({
      hidden: { opacity: 0, y: 14 },
      show: { opacity: 1, y: 0 },
    }),
    [],
  );

  const miniRows: MiniRow[] = useMemo(
    () => [
      { title: "Approvals", icon: Layers },
      { title: "Assignments", icon: LayoutGrid },
      { title: "Sync", icon: Shield },
    ],
    [],
  );

  return (
    <section className="glide-bg relative overflow-hidden" aria-label="Hero">
      <div className="noise absolute inset-0" aria-hidden={true} />

      <Container className="relative py-14 sm:py-20">
        <div className="grid items-center gap-10 lg:grid-cols-[1.1fr_0.9fr]">
          <div>
            <motion.div
              initial="hidden"
              animate="show"
              variants={variants}
              transition={{ duration: 0.55, ease: [0.2, 0.8, 0.2, 1] }}
            >
              <Badge
                className="rounded-full border bg-background/60 px-3 py-1 text-xs text-foreground shadow-sm"
                data-testid="badge-hero-announcement"
              >
                <span className="inline-flex items-center gap-2">
                  <span className="inline-flex h-5 w-5 items-center justify-center rounded-full bg-secondary">
                    <Wand2 className="h-3.5 w-3.5" aria-hidden={true} />
                  </span>
                  Build sleek apps from your data — fast
                  <span className="inline-flex items-center gap-1 text-muted-foreground">
                    See how
                    <ArrowRight className="h-3.5 w-3.5" aria-hidden={true} />
                  </span>
                </span>
              </Badge>

              <h1
                className="text-display mt-5 text-balance text-4xl font-semibold leading-[1.03] sm:text-6xl"
                data-testid="text-hero-title"
              >
                Create beautiful apps your team actually uses.
              </h1>

              <p
                className="mt-5 max-w-[56ch] text-pretty text-base text-muted-foreground sm:text-lg"
                data-testid="text-hero-subtitle"
              >
                A Glide-inspired landing page prototype: crisp typography, generous whitespace, and a product-first layout.
              </p>

              <div className="mt-7 flex flex-col gap-3 sm:flex-row sm:items-center">
                <Button
                  className="h-11 rounded-full px-5"
                  data-testid="button-hero-primary"
                  onClick={() => {
                    const el = document.querySelector("#pricing");
                    (el as HTMLElement | null)?.scrollIntoView({ behavior: "smooth", block: "start" });
                  }}
                >
                  Start free
                  <ArrowRight className="ml-2 h-4 w-4" aria-hidden={true} />
                </Button>
                <Button
                  variant="secondary"
                  className="h-11 rounded-full px-5"
                  data-testid="button-hero-secondary"
                  onClick={() => {
                    const el = document.querySelector("#product");
                    (el as HTMLElement | null)?.scrollIntoView({ behavior: "smooth", block: "start" });
                  }}
                >
                  <Play className="mr-2 h-4 w-4" aria-hidden={true} />
                  Watch demo
                </Button>
              </div>

              <div className="mt-7 flex flex-wrap items-center gap-3 text-sm text-muted-foreground" data-testid="row-hero-trust">
                {[
                  "No-code feel, real design",
                  "Templates & components",
                  "Fast iteration",
                ].map((t) => (
                  <span key={t} className="inline-flex items-center gap-2">
                    <span className="grid h-5 w-5 place-items-center rounded-full bg-secondary text-foreground">
                      <Check className="h-3.5 w-3.5" aria-hidden={true} />
                    </span>
                    {t}
                  </span>
                ))}
              </div>
            </motion.div>
          </div>

          <motion.div
            initial={{ opacity: 0, y: 18 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.65, delay: 0.05, ease: [0.2, 0.8, 0.2, 1] }}
          >
            <div className="glass rounded-[28px] p-4 sm:p-5" data-testid="card-hero-preview">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <div className="h-2.5 w-2.5 rounded-full bg-red-400/80" />
                  <div className="h-2.5 w-2.5 rounded-full bg-yellow-400/80" />
                  <div className="h-2.5 w-2.5 rounded-full bg-green-400/80" />
                </div>
                <div className="text-xs text-muted-foreground" data-testid="text-preview-label">
                  Live preview
                </div>
              </div>

              <div className="mt-4 grid gap-3">
                <div className="rounded-2xl border bg-background/70 p-4">
                  <div className="flex items-start justify-between gap-3">
                    <div>
                      <div className="text-display text-sm font-semibold" data-testid="text-preview-title">
                        Inventory overview
                      </div>
                      <div className="mt-1 text-xs text-muted-foreground" data-testid="text-preview-subtitle">
                        Connect tables, ship a workflow.
                      </div>
                    </div>
                    <Badge className="rounded-full" data-testid="badge-preview-status">
                      Ready
                    </Badge>
                  </div>

                  <div className="mt-4 grid grid-cols-3 gap-2" data-testid="grid-preview-metrics">
                    {[
                      { label: "Items", value: "1,284" },
                      { label: "Low stock", value: "23" },
                      { label: "Alerts", value: "7" },
                    ].map((m) => (
                      <div key={m.label} className="rounded-xl border bg-background/60 p-3">
                        <div className="text-xs text-muted-foreground" data-testid={`text-metric-label-${m.label.toLowerCase().replace(/\s+/g, "-")}`}>
                          {m.label}
                        </div>
                        <div className="text-display mt-1 text-lg font-semibold" data-testid={`text-metric-value-${m.label.toLowerCase().replace(/\s+/g, "-")}`}>
                          {m.value}
                        </div>
                      </div>
                    ))}
                  </div>
                </div>

                <div className="grid gap-2 rounded-2xl border bg-background/70 p-4">
                  {miniRows.map((row) => (
                    <div key={row.title} className="flex items-center justify-between rounded-xl border bg-background/60 px-3 py-2">
                      <div className="flex items-center gap-2">
                        <span className="grid h-7 w-7 place-items-center rounded-xl bg-secondary">
                          <row.icon className="h-4 w-4" />
                        </span>
                        <span className="text-sm" data-testid={`text-preview-row-${row.title.toLowerCase()}`}>{row.title}</span>
                      </div>
                      <ChevronDown className="h-4 w-4 text-muted-foreground" aria-hidden={true} />
                    </div>
                  ))}
                </div>
              </div>
            </div>
          </motion.div>
        </div>
      </Container>
    </section>
  );
}

function SectionHeading(props: { eyebrow: string; title: string; desc: string; id?: string }) {
  return (
    <div className="mx-auto max-w-[760px] text-center">
      <div className="text-xs font-semibold tracking-wide text-muted-foreground" data-testid={`text-eyebrow-${props.eyebrow.toLowerCase().replace(/\s+/g, "-")}`}>
        {props.eyebrow}
      </div>
      <h2 className="text-display mt-3 text-3xl font-semibold sm:text-4xl" data-testid={`text-section-title-${props.title.toLowerCase().replace(/\s+/g, "-")}`}>
        {props.title}
      </h2>
      <p className="mt-4 text-pretty text-muted-foreground" data-testid={`text-section-desc-${props.title.toLowerCase().replace(/\s+/g, "-")}`}>
        {props.desc}
      </p>
    </div>
  );
}

function FeatureGrid() {
  const items = [
    {
      icon: Wand2,
      title: "Design-first components",
      desc: "Cards, tables, forms and navigation that feel native — not bolted on.",
    },
    {
      icon: Code2,
      title: "Logic without the mess",
      desc: "Prototype flows quickly with clear UI states and friendly empty screens.",
    },
    {
      icon: LayoutGrid,
      title: "From data to interface",
      desc: "Turn structured data into a polished experience with sensible defaults.",
    },
    {
      icon: Shield,
      title: "Built for teams",
      desc: "Roles, approval patterns, and shared ownership — presented cleanly.",
    },
  ];

  return (
    <section id="product" className="py-14 sm:py-20" aria-label="Product">
      <Container>
        <SectionHeading
          eyebrow="Product"
          title="Everything you need to ship internal apps"
          desc="A tight, Glide-inspired layout: simple shapes, strong hierarchy, and subtle depth."
        />

        <div className="mt-10 grid gap-4 md:grid-cols-2" data-testid="grid-feature-cards">
          {items.map((it) => (
            <Card
              key={it.title}
              className="group relative overflow-hidden rounded-3xl border bg-card p-6 shadow-sm transition hover:-translate-y-0.5 hover:shadow-md"
              data-testid={`card-feature-${it.title.toLowerCase().replace(/\s+/g, "-")}`}
            >
              <div className="absolute -right-16 -top-16 h-40 w-40 rounded-full bg-[hsl(var(--primary))]/10 blur-2xl" aria-hidden={true} />
              <div className="absolute -left-16 -bottom-16 h-40 w-40 rounded-full bg-[hsl(var(--accent))]/10 blur-2xl" aria-hidden={true} />

              <div className="flex items-start justify-between gap-6">
                <div>
                  <div className="flex items-center gap-3">
                    <span className="grid h-11 w-11 place-items-center rounded-2xl bg-secondary">
                      <it.icon className="h-5 w-5" aria-hidden={true} />
                    </span>
                    <div className="text-display text-lg font-semibold" data-testid={`text-feature-title-${it.title.toLowerCase().replace(/\s+/g, "-")}`}>
                      {it.title}
                    </div>
                  </div>

                  <p className="mt-4 text-sm leading-relaxed text-muted-foreground" data-testid={`text-feature-desc-${it.title.toLowerCase().replace(/\s+/g, "-")}`}>
                    {it.desc}
                  </p>
                </div>

                <ArrowRight
                  className="mt-1 h-4 w-4 text-muted-foreground transition group-hover:translate-x-0.5 group-hover:text-foreground"
                  aria-hidden={true}
                />
              </div>
            </Card>
          ))}
        </div>
      </Container>
    </section>
  );
}

function TemplatesStrip() {
  const templates = [
    { title: "Client onboarding", tag: "Operations" },
    { title: "Bug triage", tag: "Engineering" },
    { title: "Content calendar", tag: "Marketing" },
    { title: "Inventory & PO", tag: "Retail" },
    { title: "Team directory", tag: "People" },
  ];

  return (
    <section id="templates" className="py-14 sm:py-20" aria-label="Templates">
      <Container>
        <div className="mx-auto max-w-[900px] rounded-[34px] border bg-card p-6 sm:p-10 shadow-sm" data-testid="panel-templates">
          <div className="flex flex-col items-start justify-between gap-6 sm:flex-row sm:items-end">
            <div>
              <div className="text-xs font-semibold tracking-wide text-muted-foreground" data-testid="text-templates-eyebrow">
                Templates
              </div>
              <h3 className="text-display mt-3 text-2xl font-semibold sm:text-3xl" data-testid="text-templates-title">
                Start from a proven layout
              </h3>
              <p className="mt-3 max-w-[56ch] text-sm text-muted-foreground" data-testid="text-templates-desc">
                A carousel-like strip (without the heavy UI): quick picks, clean cards, and a bright CTA.
              </p>
            </div>
            <Button className="rounded-full" data-testid="button-templates-browse">
              Browse templates
              <ArrowRight className="ml-2 h-4 w-4" aria-hidden={true} />
            </Button>
          </div>

          <div className="mt-8 grid gap-3 sm:grid-cols-2 lg:grid-cols-3" data-testid="grid-templates">
            {templates.map((t) => (
              <div
                key={t.title}
                className="group rounded-3xl border bg-background/60 p-4 transition hover:-translate-y-0.5 hover:shadow-md"
                data-testid={`card-template-${t.title.toLowerCase().replace(/\s+/g, "-")}`}
              >
                <div className="flex items-center justify-between gap-3">
                  <div className="text-display text-sm font-semibold" data-testid={`text-template-title-${t.title.toLowerCase().replace(/\s+/g, "-")}`}>
                    {t.title}
                  </div>
                  <Badge variant="secondary" className="rounded-full" data-testid={`badge-template-tag-${t.tag.toLowerCase()}`}>
                    {t.tag}
                  </Badge>
                </div>
                <div className="mt-4 flex items-center justify-between">
                  <div className="text-xs text-muted-foreground" data-testid={`text-template-meta-${t.title.toLowerCase().replace(/\s+/g, "-")}`}>
                    6 screens • 2 roles
                  </div>
                  <ArrowRight className="h-4 w-4 text-muted-foreground transition group-hover:translate-x-0.5 group-hover:text-foreground" aria-hidden={true} />
                </div>
              </div>
            ))}
          </div>
        </div>
      </Container>
    </section>
  );
}

function Pricing() {
  const plans = [
    {
      name: "Starter",
      price: "$0",
      note: "For exploring",
      features: ["Unlimited drafts", "Share previews", "Basic components"],
      highlight: false,
    },
    {
      name: "Team",
      price: "$29",
      note: "Per editor/month",
      features: ["Team workspaces", "Reusable templates", "Permissions patterns"],
      highlight: true,
    },
    {
      name: "Business",
      price: "$79",
      note: "Per editor/month",
      features: ["Advanced governance", "Audit-friendly UI", "Priority support"],
      highlight: false,
    },
  ];

  return (
    <section id="pricing" className="py-14 sm:py-20" aria-label="Pricing">
      <Container>
        <SectionHeading
          eyebrow="Pricing"
          title="Simple plans that scale"
          desc="This is a visual replica-style layout only — swap copy, pricing, and links as needed."
        />

        <div className="mt-10 grid gap-4 lg:grid-cols-3" data-testid="grid-pricing">
          {plans.map((p) => (
            <Card
              key={p.name}
              className={cx(
                "relative rounded-3xl border bg-card p-6 shadow-sm",
                p.highlight && "border-transparent bg-gradient-to-b from-[hsl(var(--primary))]/10 to-transparent",
              )}
              data-testid={`card-plan-${p.name.toLowerCase()}`}
            >
              {p.highlight ? (
                <div className="absolute inset-x-0 -top-3 flex justify-center">
                  <Badge className="rounded-full" data-testid="badge-plan-popular">
                    Most popular
                  </Badge>
                </div>
              ) : null}

              <div className="flex items-start justify-between">
                <div>
                  <div className="text-display text-lg font-semibold" data-testid={`text-plan-name-${p.name.toLowerCase()}`}>
                    {p.name}
                  </div>
                  <div className="mt-1 text-sm text-muted-foreground" data-testid={`text-plan-note-${p.name.toLowerCase()}`}>
                    {p.note}
                  </div>
                </div>
              </div>

              <div className="mt-5 flex items-baseline gap-2">
                <div className="text-display text-4xl font-semibold" data-testid={`text-plan-price-${p.name.toLowerCase()}`}>
                  {p.price}
                </div>
                <div className="text-sm text-muted-foreground">/mo</div>
              </div>

              <Button
                className={cx("mt-6 w-full rounded-2xl", !p.highlight && "bg-secondary text-foreground hover:bg-secondary/80")}
                data-testid={`button-plan-choose-${p.name.toLowerCase()}`}
              >
                Choose {p.name}
              </Button>

              <div className="mt-6 grid gap-2" data-testid={`list-plan-features-${p.name.toLowerCase()}`}>
                {p.features.map((f) => (
                  <div key={f} className="flex items-start gap-2 text-sm text-muted-foreground">
                    <span className="mt-0.5 grid h-5 w-5 place-items-center rounded-full bg-secondary text-foreground">
                      <Check className="h-3.5 w-3.5" aria-hidden={true} />
                    </span>
                    <span data-testid={`text-plan-feature-${p.name.toLowerCase()}-${f.toLowerCase().replace(/\s+/g, "-")}`}>{f}</span>
                  </div>
                ))}
              </div>
            </Card>
          ))}
        </div>
      </Container>
    </section>
  );
}

function FAQ() {
  return (
    <section className="py-14 sm:py-20" aria-label="FAQ">
      <Container>
        <SectionHeading
          eyebrow="FAQ"
          title="Questions, answered"
          desc="A lightweight accordion section to match the typical SaaS landing structure."
        />

        <div className="mx-auto mt-10 max-w-[900px] rounded-[34px] border bg-card p-2 sm:p-4" data-testid="panel-faq">
          <Accordion type="single" collapsible className="w-full">
            <AccordionItem value="item-1">
              <AccordionTrigger data-testid="button-faq-what-is-this">
                Is this an exact copy of Glide?
              </AccordionTrigger>
              <AccordionContent data-testid="text-faq-what-is-this">
                No — it’s a clean-room, Glide-inspired layout: similar spacing, hierarchy, and polish, but with original copy and UI.
              </AccordionContent>
            </AccordionItem>
            <AccordionItem value="item-2">
              <AccordionTrigger data-testid="button-faq-screenshots">
                Can you take screenshots of glideapps.com?
              </AccordionTrigger>
              <AccordionContent data-testid="text-faq-screenshots">
                I can’t capture or provide screenshots from external websites here. But I can recreate the look/feel and structure based on your description, and you can provide reference screenshots if you want it pixel-tight.
              </AccordionContent>
            </AccordionItem>
            <AccordionItem value="item-3">
              <AccordionTrigger data-testid="button-faq-claude">
                Can I copy this into Claude Code?
              </AccordionTrigger>
              <AccordionContent data-testid="text-faq-claude">
                Yes — this page is self-contained in a single route plus a design system in CSS. If you tell me your target stack, I can output a minimal file bundle or a single HTML+CSS version.
              </AccordionContent>
            </AccordionItem>
          </Accordion>
        </div>
      </Container>
    </section>
  );
}

function Footer() {
  return (
    <footer className="border-t py-10" aria-label="Footer">
      <Container>
        <div className="flex flex-col justify-between gap-6 sm:flex-row sm:items-center">
          <div className="flex items-center gap-3">
            <div className="grid h-9 w-9 place-items-center rounded-xl bg-gradient-to-br from-[hsl(var(--primary))] to-[hsl(var(--accent))] text-white shadow" />
            <div>
              <div className="text-display text-sm font-semibold" data-testid="text-footer-brand">
                Glide-ish
              </div>
              <div className="text-xs text-muted-foreground" data-testid="text-footer-note">
                Landing prototype
              </div>
            </div>
          </div>

          <div className="flex flex-wrap items-center gap-4 text-sm text-muted-foreground" data-testid="row-footer-links">
            {[
              { label: "Privacy", href: "#" },
              { label: "Terms", href: "#" },
              { label: "Status", href: "#" },
              { label: "Contact", href: "#" },
            ].map((l) => (
              <a
                key={l.label}
                href={l.href}
                className="transition-colors hover:text-foreground"
                data-testid={`link-footer-${l.label.toLowerCase()}`}
              >
                {l.label}
              </a>
            ))}
          </div>
        </div>
      </Container>
    </footer>
  );
}

export default function Landing() {
  useSmoothHashScroll();

  return (
    <main data-testid="page-landing">
      <TopNav />
      <Hero />
      <FeatureGrid />
      <TemplatesStrip />
      <Pricing />
      <FAQ />
      <Footer />
    </main>
  );
}
